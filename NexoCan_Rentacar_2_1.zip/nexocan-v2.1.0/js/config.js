// NexoCan Rent a Car · Configuración de la versión entregada para revisión.
window.NEXOCAN_CONFIG = {
  entorno: 'pruebas',
  nivelLog: 'DEBUG',
  responsable: 'Equipo de preproduccion',
  urlFlota: './datos/flota-demo.json'
};
