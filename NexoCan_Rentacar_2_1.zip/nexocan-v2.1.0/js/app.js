/* NexoCan Rent a Car · Motor de consulta de flota. NO modificar en el examen. */
(() => {
  'use strict';
  const configuracion = window.NEXOCAN_CONFIG;
  const $ = (selector) => document.querySelector(selector);
  let vehiculos = [];
  function seguro(valor) { return String(valor).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;', "'":'&#39;'}[c])); }
  function mostrarConfiguracion() {
    $('#dato-responsable').textContent = configuracion?.responsable || 'Sin configurar';
    $('#dato-entorno').textContent = configuracion?.entorno || 'Sin configurar';
    $('#dato-log').textContent = configuracion?.nivelLog || 'Sin configurar';
  }
  function renderizar() {
    const termino = $('#buscar').value.trim().toLocaleLowerCase('es');
    const isla = $('#isla').value;
    const categoria = $('#categoria').value;
    const filtrados = vehiculos.filter(v => (isla === 'todas' || v.isla === isla) &&
      (categoria === 'todas' || v.categoria === categoria) &&
      [v.modelo,v.isla,v.recogida,v.categoria].join(' ').toLocaleLowerCase('es').includes(termino));
    $('#contador').textContent = `${filtrados.length} de ${vehiculos.length} vehículos`;
    $('#tarjetas').innerHTML = filtrados.map(v => `<article class="car-card">
      <div class="card-top"><span class="badge-type">${seguro(v.categoria)}</span><span class="serial">${seguro(v.codigo)}</span></div>
      <div class="car-art"><img src="./assets/${seguro(v.imagen)}" alt="Imagen ilustrativa de ${seguro(v.modelo)}" loading="lazy"></div>
      <div class="car-copy"><span class="island">${seguro(v.isla)} · ${seguro(v.recogida)}</span><h3>${seguro(v.modelo)}</h3><p>${seguro(v.descripcion)}</p></div>
      <div class="car-attributes"><span>${seguro(v.plazas)}</span><span>${seguro(v.cambio)}</span></div>
      <div class="car-bottom"><div><small>Desde</small><strong>${Number(v.precioDia)} €<em> / día</em></strong></div><button type="button" class="solicitar" data-codigo="${seguro(v.codigo)}">Consultar disponibilidad</button></div>
      </article>`).join('');
    $('#mensaje').textContent = filtrados.length ? '' : 'No se encontraron vehículos con los filtros seleccionados.';
  }
  async function iniciar() {
    mostrarConfiguracion();
    if (!configuracion?.urlFlota) {
      $('#mensaje').textContent = 'ERROR: la configuración del servicio no está disponible.';
      $('#dato-estado').textContent = 'DESPLIEGUE PENDIENTE';
      $('#dato-estado').classList.add('error');
      return;
    }
    try {
      const respuesta = await fetch(configuracion.urlFlota, {cache:'no-store'});
      if (!respuesta.ok) throw new Error(`HTTP ${respuesta.status}`);
      const datos = await respuesta.json();
      if (!Array.isArray(datos.vehiculos)) throw new Error('El catálogo no contiene vehículos.');
      vehiculos = datos.vehiculos;
      $('#stat-coches').textContent = vehiculos.length;
      $('#dato-flota').textContent = `${vehiculos.length} vehículos`;
      const islas = [...new Set(vehiculos.map(v => v.isla))];
      for (const isla of islas) { const o = document.createElement('option'); o.value = isla; o.textContent = isla; $('#isla').append(o); }
      $('#dato-estado').textContent = 'FLOTA CARGADA · CONFIGURACIÓN APLICADA';
      $('#dato-estado').classList.add('correcto');
      $('#buscar').addEventListener('input', renderizar);
      $('#isla').addEventListener('change', renderizar);
      $('#categoria').addEventListener('change', renderizar);
      $('#tarjetas').addEventListener('click', e => {
        const boton = e.target.closest('.solicitar');
        if (boton) $('#mensaje').textContent = 'Consulta simulada registrada para el vehículo ' + boton.dataset.codigo + '. No se ha enviado ninguna reserva.';
      });
      renderizar();
    } catch (error) {
      $('#mensaje').textContent = `ERROR: no se ha podido cargar la flota (${error.message}).`;
      $('#dato-flota').textContent = 'Error de lectura';
      $('#dato-estado').textContent = 'DESPLIEGUE PENDIENTE';
      $('#dato-estado').classList.add('error');
      console.error(error);
    }
  }
  iniciar();
})();
